<?php $__env->startSection('content'); ?>

	
	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-admin.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastart\resources\views/admin/users.blade.php ENDPATH**/ ?>