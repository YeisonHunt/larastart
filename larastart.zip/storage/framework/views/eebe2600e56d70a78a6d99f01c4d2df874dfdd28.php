<?php $__env->startSection('content'); ?>

Dashboard 1

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastart\resources\views/admin/index.blade.php ENDPATH**/ ?>