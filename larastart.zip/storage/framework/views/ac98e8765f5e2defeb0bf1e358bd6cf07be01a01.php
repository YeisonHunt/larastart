<?php $__env->startSection('content'); ?>

	Dashboard 2

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastart\resources\views/admin/dashboard2.blade.php ENDPATH**/ ?>