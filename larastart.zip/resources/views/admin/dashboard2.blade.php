
@extends('layout-admin.master')

@section('content')

	Dashboard 2

@endsection